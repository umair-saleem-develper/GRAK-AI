import json
import asyncio
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional

from database import get_db
from models import User, Conversation, Message, AIUsage
from services.auth import get_current_user
from services.ai.gateway import AIGateway

router = APIRouter(prefix="/api/chat", tags=["Chat"])
gateway = AIGateway()

class MessageRequest(BaseModel):
    conversation_id: Optional[str] = None
    content: str
    uploaded_text: Optional[str] = None # Text extracted from uploaded files to prepend

def generate_title_task(conversation_id: str, first_message: str):
    """Background task to generate a title for a new conversation."""
    # We must create a new DB session for the background task
    from database import SessionLocal
    db = SessionLocal()
    try:
        conv = db.query(Conversation).filter(Conversation.id == conversation_id).first()
        if not conv:
            return
            
        prompt = f"Generate a short (max 5 words) title for a conversation that starts with this message:\n\n{first_message}"
        messages = [{"role": "user", "content": prompt}]
        
        # Use gateway directly, blocking event loop slightly is OK for background task 
        # or use asyncio.run if this was a sync function, but fastapi background tasks can be async
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            response = loop.run_until_complete(gateway.chat(messages))
            conv.title = response.content.strip().strip('"').strip("'")
            db.commit()
        except Exception as e:
            pass # Ignore failure in title generation
        finally:
            loop.close()
    finally:
        db.close()

async def async_generate_title_task(conversation_id: str, first_message: str):
    from database import SessionLocal
    db = SessionLocal()
    try:
        conv = db.query(Conversation).filter(Conversation.id == conversation_id).first()
        if not conv:
            return
            
        prompt = f"Generate a very short, plain text title (max 5 words) for a chat starting with: {first_message[:200]}"
        messages = [{"role": "user", "content": prompt}]
        
        try:
            response = await gateway.chat(messages)
            # Cleanup common quotes or markdown
            title = response.content.strip().replace('"', '').replace('`', '').replace('*', '')
            if len(title) > 50:
                title = title[:47] + "..."
            conv.title = title
            db.commit()
        except Exception as e:
            pass 
    finally:
        db.close()

@router.post("/stream")
async def send_message(
    request: Request,
    msg_req: MessageRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Handles streaming AI response.
    Lazy initializes conversation if not provided.
    """
    # 1. Lazy Initialization of Conversation
    conversation_id = msg_req.conversation_id
    is_new_conversation = False
    
    if not conversation_id:
        conv = Conversation(user_id=current_user.id, title="New Chat")
        db.add(conv)
        db.commit()
        db.refresh(conv)
        conversation_id = conv.id
        is_new_conversation = True
    else:
        conv = db.query(Conversation).filter(
            Conversation.id == conversation_id,
            Conversation.user_id == current_user.id,
            Conversation.deleted_at == None
        ).first()
        if not conv:
            raise HTTPException(status_code=404, detail="Conversation not found")

    # 2. Save User Message
    full_content = msg_req.content
    if msg_req.uploaded_text:
        full_content = f"Attached Document Context:\n{msg_req.uploaded_text}\n\nUser Message: {msg_req.content}"
        
    user_msg = Message(
        conversation_id=conversation_id,
        role="user",
        content=full_content
    )
    db.add(user_msg)
    db.commit()
    db.refresh(user_msg)
    
    # Trigger async title generation for new chats
    if is_new_conversation:
        background_tasks.add_task(async_generate_title_task, conversation_id, msg_req.content)

    # 3. Retrieve Conversation History
    history_msgs = db.query(Message).filter(Message.conversation_id == conversation_id).order_by(Message.created_at).all()
    # Format for AI Provider
    formatted_history = []
    for m in history_msgs:
        formatted_history.append({"role": m.role, "content": m.content})
        
    # SSE Stream Generator
    async def sse_generator():
        yield f"data: {json.dumps({'type': 'meta', 'conversation_id': conversation_id})}\n\n"
        
        full_assistant_response = ""
        final_model = ""
        final_provider = ""
        total_tokens = 0
        prompt_tokens = 0
        completion_tokens = 0
        
        import time
        start_time = time.time()
        
        try:
            # We catch disconnects inside the stream
            stream = gateway.stream(formatted_history)
            async for chunk in stream:
                if await request.is_disconnected():
                    break # Client disconnected, stop generating
                    
                if chunk.content:
                    full_assistant_response += chunk.content
                    payload = json.dumps({"type": "chunk", "content": chunk.content})
                    yield f"data: {payload}\n\n"
                    
                if chunk.is_done:
                    # Final chunk with metrics
                    final_model = chunk.model
                    final_provider = chunk.provider
                    total_tokens = chunk.total_tokens
                    prompt_tokens = chunk.prompt_tokens
                    completion_tokens = chunk.completion_tokens
                    
            # 4. Success - Save Assistant Message
            latency = time.time() - start_time
            
            # Re-open session since we are in a generator
            from database import SessionLocal
            stream_db = SessionLocal()
            try:
                assistant_msg = Message(
                    conversation_id=conversation_id,
                    role="assistant",
                    content=full_assistant_response,
                    provider=final_provider,
                    model=final_model,
                    tokens_used=total_tokens
                )
                stream_db.add(assistant_msg)
                
                # Update conversation updated_at
                conv = stream_db.query(Conversation).filter(Conversation.id == conversation_id).first()
                if conv:
                    from sqlalchemy.sql import func
                    conv.updated_at = func.now()
                
                # 5. Log AI Usage
                usage = AIUsage(
                    user_id=current_user.id,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_tokens=total_tokens,
                    provider=final_provider,
                    model=final_model,
                    latency=latency,
                    estimated_cost=0.0 # Calculate based on provider/model later
                )
                stream_db.add(usage)
                
                stream_db.commit()
            finally:
                stream_db.close()
                
            yield f"data: {json.dumps({'type': 'done'})}\n\n"
            
        except Exception as e:
            # Failure occurred that gateway couldn't handle
            # Save failure message to preserve state
            import logging
            logging.getLogger(__name__).error(f"Stream generation failed: {e}")
            
            from database import SessionLocal
            err_db = SessionLocal()
            try:
                err_msg = Message(
                    conversation_id=conversation_id,
                    role="assistant",
                    content=f"An error occurred while generating the response: {str(e)}",
                    provider="error",
                    model="error",
                    tokens_used=0
                )
                err_db.add(err_msg)
                err_db.commit()
            finally:
                err_db.close()
                
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"

    return StreamingResponse(sse_generator(), media_type="text/event-stream")
