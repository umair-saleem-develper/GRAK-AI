import io
from docx import Document
import PyPDF2

class DocumentParser:
    @staticmethod
    def parse_txt(content: bytes) -> str:
        return content.decode("utf-8", errors="replace")

    @staticmethod
    def parse_pdf(content: bytes) -> str:
        text = ""
        try:
            reader = PyPDF2.PdfReader(io.BytesIO(content))
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
        except Exception as e:
            text = f"[Error parsing PDF: {e}]"
        return text

    @staticmethod
    def parse_docx(content: bytes) -> str:
        text = ""
        try:
            doc = Document(io.BytesIO(content))
            for para in doc.paragraphs:
                text += para.text + "\n"
        except Exception as e:
            text = f"[Error parsing DOCX: {e}]"
        return text

    @classmethod
    def parse_file(cls, content: bytes, content_type: str, filename: str) -> str:
        if "pdf" in content_type.lower() or filename.lower().endswith(".pdf"):
            return cls.parse_pdf(content)
        elif "word" in content_type.lower() or "docx" in content_type.lower() or filename.lower().endswith(".docx"):
            return cls.parse_docx(content)
        elif "text" in content_type.lower() or filename.lower().endswith(".txt") or filename.lower().endswith(".md"):
            return cls.parse_txt(content)
        else:
            # Fallback to pure text decoding for unknown formats if they are text
            try:
                return content.decode("utf-8")
            except:
                return "[Unsupported file format or binary data]"
