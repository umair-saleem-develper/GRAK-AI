from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from database import get_db
from models import User, Upload
from services.auth import get_current_user
from services.document_parser import DocumentParser

router = APIRouter(prefix="/api/uploads", tags=["Uploads"])

@router.post("")
async def upload_file(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Read the file content
    content = await file.read()
    
    # Extract text from file
    extracted_text = DocumentParser.parse_file(content, file.content_type, file.filename)
    
    if not extracted_text or extracted_text.startswith("[Unsupported"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not extract text from file or unsupported format."
        )
    
    # Save Upload metadata to database (simulating storage)
    # We do not actually store the file on disk yet per instructions (avoid leaking temporary files)
    # The text itself is returned to the frontend to be appended to the next message.
    
    upload_record = Upload(
        user_id=current_user.id,
        filename=file.filename,
        file_url=f"local://extracted/{file.filename}",
        file_type=file.content_type,
        storage_provider="local_memory"
    )
    db.add(upload_record)
    db.commit()
    db.refresh(upload_record)
    
    return {
        "id": upload_record.id,
        "filename": upload_record.filename,
        "extracted_text": extracted_text
    }
