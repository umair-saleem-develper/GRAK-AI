import google.generativeai as genai

API_KEY = "AQ.Ab8RN6IlGfYl34oDxkDNuE8sz68ldlfc8TysaY55uUfML9HA1w"

try:
    genai.configure(api_key=API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
    response = model.generate_content("Hello")
    print("SUCCESS:", response.text)
except Exception as e:
    print("ERROR:", e)
