import logging
from typing import AsyncGenerator, Dict, Any, List, Optional
from .providers.base import BaseAIProvider, AIResponse, AIStreamChunk
from .providers.gemini import GeminiProvider
from .providers.groq import GroqProvider
from .providers.openrouter import OpenRouterProvider

logger = logging.getLogger(__name__)

class AIGateway:
    """
    Lightweight AI orchestration layer managing fallback routing across providers.
    Provider Order: Gemini -> Groq -> OpenRouter
    """
    def __init__(self):
        self.providers: List[BaseAIProvider] = []
        
        # Initialize providers securely, skipping if keys are missing (but shouldn't be in production)
        try:
            self.providers.append(GeminiProvider())
        except ValueError as e:
            logger.warning(f"Failed to init Gemini: {e}")
            
        try:
            self.providers.append(GroqProvider())
        except ValueError as e:
            logger.warning(f"Failed to init Groq: {e}")
            
        try:
            self.providers.append(OpenRouterProvider())
        except ValueError as e:
            logger.warning(f"Failed to init OpenRouter: {e}")

    def get_model_for_provider(self, provider_name: str) -> str:
        """Map generic fallback logic to specific models for each provider."""
        mapping = {
            "gemini": "gemini-1.5-flash",
            "groq": "llama3-8b-8192",
            "openrouter": "meta-llama/llama-3-8b-instruct"
        }
        return mapping.get(provider_name, "gemini-1.5-flash")

    async def chat(self, messages: List[Dict[str, str]]) -> AIResponse:
        """Execute a synchronous chat generation with automatic failover."""
        last_error = None
        
        for provider in self.providers:
            model = self.get_model_for_provider(provider.provider_name)
            logger.info(f"[AIGateway] Attempting chat via {provider.provider_name} ({model})")
            try:
                response = await provider.chat(messages=messages, model=model)
                return response
            except Exception as e:
                logger.error(f"[AIGateway] {provider.provider_name} failed: {e}")
                last_error = e
                continue
                
        # If we reach here, all providers failed
        raise RuntimeError(f"All AI providers failed. Last error: {last_error}")

    async def stream(self, messages: List[Dict[str, str]]) -> AsyncGenerator[AIStreamChunk, None]:
        """Execute a streaming chat generation with automatic failover at the connection level."""
        last_error = None
        
        for provider in self.providers:
            model = self.get_model_for_provider(provider.provider_name)
            logger.info(f"[AIGateway] Attempting stream via {provider.provider_name} ({model})")
            first_chunk_yielded = False
            try:
                # We fetch the stream object. If it connects, we start yielding.
                # If it fails before the first yield, we can catch it. 
                # If it fails MID-STREAM, it's harder to failover seamlessly, but we can try.
                stream_gen = provider.stream(messages=messages, model=model)
                
                # Fetch first chunk to verify connection works
                async for chunk in stream_gen:
                    first_chunk_yielded = True
                    yield chunk
                    
                return # Successfully finished streaming, exit function
                
            except Exception as e:
                logger.error(f"[AIGateway] {provider.provider_name} failed: {e}")
                last_error = e
                # If we already yielded some chunks to the user, we cannot seamlessly failover
                # because the frontend already has partial text. We must raise or gracefully terminate.
                if first_chunk_yielded:
                    logger.error("[AIGateway] Provider failed mid-stream. Yielding error chunk.")
                    yield AIStreamChunk(
                        content="\n[Error: Stream interrupted and cannot be seamlessly recovered.]",
                        is_done=True,
                        model=model,
                        provider=provider.provider_name
                    )
                    return
                # If not yielded yet, we continue to next provider (seamless failover)
                continue
                
        # If all providers failed before yielding anything
        # We don't raise 500, we yield a failure chunk
        yield AIStreamChunk(
            content="I am currently experiencing high demand and all backup systems are offline. Please try again later.",
            is_done=True,
            model="failover-error",
            provider="none"
        )
