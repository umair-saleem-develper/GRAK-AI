import os
from typing import AsyncGenerator, Dict, Any, List
from google import genai
from .base import BaseAIProvider, AIResponse, AIStreamChunk

class GeminiProvider(BaseAIProvider):
    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY is not set")
        self.client = genai.Client(api_key=self.api_key)

    @property
    def provider_name(self) -> str:
        return "gemini"

    def _convert_messages(self, messages: List[Dict[str, str]]) -> List[Dict[str, str]]:
        # Map generic 'user'/'assistant' roles to Gemini roles if needed
        # Actually google-genai expects {"role": "user", "parts": [{"text": "..."}]}
        gemini_messages = []
        for msg in messages:
            role = msg["role"]
            if role == "assistant":
                role = "model"
            elif role == "system":
                # system instructions are typically passed differently, but for simplicity we can treat as user if not supported directly, or pass in config
                role = "user"
            gemini_messages.append({
                "role": role,
                "parts": [{"text": msg["content"]}]
            })
        return gemini_messages

    async def chat(self, messages: List[Dict[str, str]], model: str, **kwargs) -> AIResponse:
        contents = self._convert_messages(messages)
        # Using aio execution wrapper if available, or sync wrapper if we must
        # google-genai uses aio client under self.client.aio
        
        response = await self.client.aio.models.generate_content(
            model=model,
            contents=contents
        )
        
        # Token usage from response.usage_metadata
        usage = response.usage_metadata
        prompt_tokens = getattr(usage, "prompt_token_count", 0) if usage else 0
        completion_tokens = getattr(usage, "candidates_token_count", 0) if usage else 0
        total_tokens = getattr(usage, "total_token_count", 0) if usage else 0

        return AIResponse(
            content=response.text,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            model=model,
            provider=self.provider_name
        )

    async def stream(self, messages: List[Dict[str, str]], model: str, **kwargs) -> AsyncGenerator[AIStreamChunk, None]:
        contents = self._convert_messages(messages)
        
        response_stream = await self.client.aio.models.generate_content_stream(
            model=model,
            contents=contents
        )
        
        async for chunk in response_stream:
            # Check if this is the final chunk with usage
            usage = chunk.usage_metadata
            prompt_tokens = getattr(usage, "prompt_token_count", 0) if usage else 0
            completion_tokens = getattr(usage, "candidates_token_count", 0) if usage else 0
            total_tokens = getattr(usage, "total_token_count", 0) if usage else 0
            
            yield AIStreamChunk(
                content=chunk.text or "",
                is_done=False, # We will yield a final empty chunk with is_done=True later
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
                model=model,
                provider=self.provider_name
            )
            
        yield AIStreamChunk(content="", is_done=True, model=model, provider=self.provider_name)

    async def embeddings(self, text: str, model: str, **kwargs) -> List[float]:
        raise NotImplementedError()

    async def image(self, prompt: str, model: str, **kwargs) -> str:
        raise NotImplementedError()
